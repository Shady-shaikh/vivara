@extends('backend.layouts.app')
@section('title', 'Backend Sub Menus')

@section('content')

    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
            <h3 class="content-header-title">Backend Menu</h3>
            <div class="row breadcrumbs-top">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item active">Backend Menu</li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="content-header-right col-md-6 col-12 mb-md-0 mb-2">
            <div class="btn-group float-md-right" role="group" aria-label="Button group with nested dropdown">
                <div class="col-12 text-right">
                    <a href="{{ route('admin.backendsubmenu.create') }}/{{ request()->menu_id }}" class="btn btn-primary"><i
                            class="bx bx-plus"></i> Add </a>
                </div>
            </div>
        </div>
    </div>

    <section id="basic-datatable">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Backend Sub Menus</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body card-dashboard">

                            <div class="table-responsive">
                                <table class="table zero-configuration" id="tbl-datatable">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Controller Name</th>
                                            <th>Method Name</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if (isset($backendsubmenus) && count($backendsubmenus) > 0)
                                            @php $srno = 1; @endphp
                                            @foreach ($backendsubmenus as $menu)
                                                <tr>
                                                    <td>{{ $srno }}</td>
                                                    <td>{{ $menu->submenu_name }}</td>
                                                    <td>{{ $menu->submenu_controller_name }}</td>
                                                    <td>{{ $menu->submenu_action_name }}</td>
                                                    <td>

                                                        <a href="{{ url('admin/backendsubmenu/edit/' . $menu->submenu_id) }}"
                                                            class="btn btn-primary">Edit</a>
                                                        {!! Form::open([
                                                            'method' => 'GET',
                                                            'url' => ['admin/backendsubmenu/delete', $menu->submenu_id],
                                                            'style' => 'display:inline',
                                                        ]) !!}
                                                        {!! Form::button('Delete', [
                                                            'type' => 'submit',
                                                            'class' => 'btn btn-danger',
                                                            'onclick' => "return confirm('Are you sure you want to Delete this Entry ?')",
                                                        ]) !!}
                                                        {!! Form::close() !!}
                                                    </td>
                                                </tr>
                                                @php $srno++; @endphp
                                            @endforeach
                                        @endif
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
@section('scripts')
    <script src="{{ asset('public/backend-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
    <script src="{{ asset('public/backend-assets/vendors/js/tables/datatable/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('public/backend-assets/vendors/js/tables/datatable/dataTables.buttons.min.js') }}"></script>

    <script>
        $(document).ready(function() {

        });
    </script>
@endsection
